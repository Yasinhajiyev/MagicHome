// json
var langJSON = {
    "en" : {
      "textile":"TEXTILE PRODUCTS",
      "bedding":"Bedding sets",
      "curtain":"Curtains and tulle",
      "carpet":"Small carpets",
      "other":"Other textiles (covers, blankets, pillows, etc.)",
      "office":"Office and other household items",
      "office1":"Office supplies",
      "cleanliness":"Cleaning items",
      "tool":"Tools and garden items",
      "boxes":"Boxes",
      "other1":"Other",
      "kitchen":"Kitchen world",
      "cooking":"Cooking world (Frying pan / pot, etc.)",
      "ready":"Preparation tools (grater, strainer and other tools)",
      "knives":"Knives and Cutting Boards",
      "store":"Storage and spice containers",
      "kitchend":"Kitchen textiles and cleaning utensils",
      "foodbag":"Food bags, sacks and packages",
      "other11":"Other 1",
      "other22":"Other 2",
      "bath":"Bathroom",
      "bathaks":"Bathroom accessories",
      "bathteks":"Bath textile",
      "footcarp":"Mats and curtains",
      "child":"Children's section",
      "toys":"Toys",
      // " ":"Textiles",
      "care":"Care and nutrition products",
      "security":"Security and other items",
      "decorative":"Decorative items",
      "clocks":"Clocks and frames",
      "flower":"Pottery and flower pots",
      "mirrors":"Mirrors",
      "candles":"Candles and candlesticks",
      "lamp":"Lamps and lighting",
      "tableware":"Tableware and utensils",
      "mealsets":"Meal sets and sevis dishes",
      "forks":"Fork / spoon / knife sets and service tools",
      "glass":"Glass, goblets, and cups",
      "tea":"Tea / coffee accessories, decanters, thermoses",
      "covers":"Covers and American services",
      "tablewareaks":"Other table accessories (napkins, trays, bread, trays)",
      "about":"About us",
      "tableware":"Tableware and utensils",
      "careers":"Careers",
      "aaaa":"Organizer and storage boxes",
      "":"",
      "":"",
      "":"",
      "":"",
      "":"",
      "":"",



    },
  
    "az" : {
      "textile":"TEKSTIL ƏŞYALARI",
      "bedding":"Yataq dəstlər",
      "curtain":"Pərdə və tüllər",
      "carpet":"Kiçik xalılar",
      "other":"Digər tekstil əşyaları (örtülər, yorğan yastıq və.s)",
      "office":"Ofis və digər ev əşyaları",
      "office1":"Ofis əşyaları",
      "cleanliness":"Təmizlik əşyaları",
      "tool":"Alət və bağ əşyaları",
      "boxes":"Qutular",
      "other1":"Digər",
      "kitchen":"Mətbəx aləmi",
      "accessories":" Mətbəx aksesuarları (divar, dolab və vanna)",
      "cooking":"Bişirmə aləmi(Tava / qazan və.s)",
      "ready":"Hazırlıq alətləri (Rəndə, süzgəc və digər alətlər) ",
      "knives":"Bıçaqlar və Kəsmə taxtaları",
      "store":"Saxlama və ədviyyat qabları",
      "kitchend":"Mətbəx tekstili və təmizlik əşyaları",
      "foodbag":"Yemək çantaları, torba və paketlər",
      "other11":"Digər 1",
      "other22":"Digər 2",
      "bath":"Hamam otağı",
      "bathaks":"Hamam aksesuarları",
      "bathteks":"Hamam tekstili",
      "footcar":"Ayaqaltı və pərdələr",
      "child":"Uşaq bölməsi",
      "toys":"Oyuncaqlar",
      // "Tekstil əşyaları ":"Tekstil əşyaları",
      "care":"Baxım və bəslənmə məhsulları",
      "security":"Təhlükəsizlik və digər əşyalar",
      "decoative":"Dekorativ əşyalar",
      "clocks":"Saat və çərçivələr",
      "flower":"Saxsı və gül qabları",
      "mirrors":"Güzgülər",
      "candles":"Şam və şamdanlar",
      "lamp":"Lampa və işıqlandırmalar",
      "tableware":"Süfrə və servis əşyaları",
      "mealsets":"Yemək dəstləri və sevis qabları",
      "forks":"Çəngəl / qaşıq / bıçaq dəstləri və servis alətləri",
      "glass":"Stəkan, qədəh, və fincanlar",
      "tea":"Çay / kofe aksesuarları, qrafinlər, termoslar ",
      "covers":"Örtülər və amerikan servislər ",
      "tablewareaks":"Digər süfrə aksesuarları (salfetkalıq, altlıq, çörək q, sinilər)",
      "about":"Haqqımızda",
      "careers":"Karyera imkanı",
      "aaaa":"Orqanayzer və saxlama qutuları",
      "":"",
      "":"",
      "":"",
      "":"",
      "":"",
      "":"",
      "":"",



    }
  }
  
  document.addEventListener("DOMContentLoaded", function(event) {
    var appLang = localStorage.getItem('lang');
  
    if(appLang === null){
      localStorage.setItem('lang', 'en');
  
      contentUpdate('en'); 
  
      document.querySelector('[data-value="en"]').checked = true; 
    }
    else{
      contentUpdate(appLang); 
  
      document.querySelector('[data-value="'+appLang+'"]').checked = true;
    }
  });
  
  function changeLang(langVal){
    localStorage.setItem('lang', langVal);
  
    contentUpdate(langVal);
  }
  
  function contentUpdate(cl){
    var currLang = Object.entries(langJSON)[Object.keys(langJSON).indexOf(cl)][1],
        langCont = Object.entries(currLang).length;
  
    for(let i = 0; i < langCont; i++){
      var getSelector = document.querySelectorAll('.langchange')[i],
          getAttr = getSelector.getAttribute('data-key');
  
      getSelector.innerHTML = currLang[getAttr];
    }
  }