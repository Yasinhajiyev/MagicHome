// ************************************************
// Shopping Cart API
// ************************************************

var shoppingCart = (function() {
  // =============================
  // Private methods and propeties
  // =============================
  cart = [];
  
  // Constructor
  function Item(name, price, count,image,description) {
    this.name = name;
    this.price = price;
    this.count = count;
    this.image=image;
    this.description=description;
  }
  
  // Save cart
  function saveCart() {
    sessionStorage.setItem('shoppingCart', JSON.stringify(cart));
  }
  
    // Load cart
  function loadCart() {
    cart = JSON.parse(sessionStorage.getItem('shoppingCart'));
  }
  if (sessionStorage.getItem("shoppingCart") != null) {
    loadCart();
  }
  

  // =============================
  // Public methods and propeties
  // =============================
  var obj = {};

  
  // Add to cart
  obj.addItemToCart = function(name, price, count,image,description) {
    for(var item in cart) {
      if(cart[item].name === name) {
        cart[item].count ++;
        saveCart();
        return;
      }
    }
    var item = new Item(name, price, count,image,description);
    cart.push(item);
    saveCart();
  }
  // Set count from item
  obj.setCountForItem = function(name, count) {
    for(var i in cart) {
      if (cart[i].name === name) {
        cart[i].count = count;
        break;
      }
    }
  };
  // Remove item from cart
  obj.removeItemFromCart = function(name) {
      for(var item in cart) {
        if(cart[item].name === name) {
          cart[item].count --;
          if(cart[item].count === 0) {
            cart.splice(item, 1);
          }
          break;
        }
    }
    saveCart();
  }

  // Remove all items from cart
  obj.removeItemFromCartAll = function(name) {
    for(var item in cart) {
      if(cart[item].name === name) {
        cart.splice(item, 1);
        break;
      }
    }
    saveCart();
  }

  // Clear cart
  obj.clearCart = function() {
    cart = [];
    saveCart();
  }

  // Count cart 
  obj.totalCount = function() {
    var totalCount = 0;
    for(var item in cart) {
      totalCount += cart[item].count;
    }
    return totalCount;
  }

  // Total cart
  obj.totalCart = function() {
    var totalCart = 0;
    for(var item in cart) {
      totalCart += cart[item].price * cart[item].count;
    }
    return Number(totalCart.toFixed(2));
  }

  // List cart
  obj.listCart = function() {
    var cartCopy = [];
    for(i in cart) {
      item = cart[i];
      itemCopy = {};
      for(p in item) {
        itemCopy[p] = item[p];

      }
      itemCopy.total = Number(item.price * item.count).toFixed(2);
      cartCopy.push(itemCopy)
    }
    return cartCopy;
  }

  // cart : Array
  // Item : Object/Class
  // addItemToCart : Function
  // removeItemFromCart : Function
  // removeItemFromCartAll : Function
  // clearCart : Function
  // countCart : Function
  // totalCart : Function
  // listCart : Function
  // saveCart : Function
  // loadCart : Function
  return obj;
})();


// *****************************************
// Triggers / Events
// ***************************************** 
// Add item
$('.add-to-cart').click(function(event) {
  event.preventDefault();
  var name = $(this).data('name');
  var price = Number($(this).data('price'));
  var image=$(this).data('image');
  var description=$(this).data('description');
  shoppingCart.addItemToCart(name, price, 1,image,description);
  displayCart();
});

// Clear items
$('.clear-cart').click(function() {
  shoppingCart.clearCart();
  displayCart();
});


function displayCart() {
  var cartArray = shoppingCart.listCart();
  var output = "";
  var output1= "";
  for(var i in cartArray) {
      output += `
      <li class="product-list">
        <a href="#" title="" class="cart-product-image"><img src="${cartArray[i].image}" class="img-fluid" alt="Futurelife" height="100" width="100"/></a>
        <div class="text">
        <p class="product-name">${cartArray[i].name}</p>
        <p class="product-price">Qiymət:${cartArray[i].price}</p>
        <p class="product-quantity">Say:${cartArray[i].count}</p>
        <p>Yekun qiymət:${cartArray[i].total}</p>
        </div>
        </li>`
       

        // if(cartArray[i].count=0){
        //   output1 +=`<span>Burada heçnə yoxdur</span>`
        // }
        // else{
          output1 +=`<tr class="item_cart" data-index="0">
          <td class="product-photo"> <img src="${cartArray[i].image}" class="img-fluid" alt="Futurelife" height="100" width="100"></td>
          <td class="produc-name">${cartArray[i].name}</td>
          <td class="description">${cartArray[i].description}</td>
          <td class="product-price" data-price="10">${cartArray[i].price}</td>
          <td><div class="input-group">
          <button class="minus-item input-group-addon btn btn-primary" data-name="${cartArray[i].name}">-</button>
          <input type="number" class="item-count form-control" data-name="${cartArray[i].name}" value="${cartArray[i].count}" onkeydown="return false //return value false">
          <button class="plus-item btn btn-primary input-group-addon" data-name="${cartArray[i].name}">+</button></div></td>
          <td class="total-price">${cartArray[i].total}</td>
          <td class="product-remove"><a class="delete-item" style="cursor: pointer" data-name="${cartArray[i].name}" title="">x</a></td>
      </tr>`
        // }
     
                         


  }
  $('.show-cart').html(output);
  $('.total-cart').html(shoppingCart.totalCart());
  $('.total-count').html(shoppingCart.totalCount());
  $('.space-80 tbody').html(output1);
}

// Delete item button

$('.space-80 tbody').on("click", ".delete-item", function(event) {
  var name = $(this).data('name')
  shoppingCart.removeItemFromCartAll(name);
  displayCart();
})


// -1
$('.space-80 tbody').on("click", ".minus-item", function(event) {
  var name = $(this).data('name')
  shoppingCart.removeItemFromCart(name);
  displayCart();
})
// +1
$('.space-80 tbody').on("click", ".plus-item", function(event) {
  var name = $(this).data('name')
  shoppingCart.addItemToCart(name);
  displayCart();
})

// Item count input
$('.show-cart').on("change", ".item-count", function(event) {
   var name = $(this).data('name');
   var count = Number($(this).val());
  shoppingCart.setCountForItem(name, count);
  displayCart();
});

displayCart();
