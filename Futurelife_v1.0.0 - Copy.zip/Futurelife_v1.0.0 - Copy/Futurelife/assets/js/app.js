    $(".cates").click(function () {
        $(".subc").slideUp()
        $(this).find('.subc').stop().slideToggle()
      })
    
    $(".header-wrapper button").click(function(){
        $(".menu").fadeIn()
            $(".tp-leftarrow").addClass("active-prev")
            
    })

    jQuery(document).ready(function ($) {
        $('.hero').slick({
          dots:true,
          infinite: true,
          speed: 500,
          fade: !0,
          cssEase: 'linear',
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 8000,
          draggable: true,
          arrows: false,
          responsive: [
          {
          breakpoint: 1024,
          settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true
                    }
          },
          {
          breakpoint: 768,
          settings: {
          draggable: true,
                    }
          },
          {
          breakpoint: 600,
          settings: {
          slidesToShow: 1,
          draggable: true,
          slidesToScroll: 1
                    }
          },
          {
          breakpoint: 480,
          settings: {
          slidesToShow: 1,
          draggable: true,
          slidesToScroll: 1
                    }
          }
      
                    ]
                    });
          });		
    $("#closeico").click(function(){
        $(".menu").fadeOut()
            $(".tp-leftarrow").removeClass("active-prev")
    })
    
    
    $(document).mouseup(function (e) {
        if ($(e.target).closest(".menu").length=== 0) {
            $(".menu").fadeOut();
            $(".tp-leftarrow").removeClass("active-prev")
    
        }
    });
    
    $("absolute-fav").click(function(){
        $(".fav-box").addClass("box-active")
    })
    
    $(".product .action i").click(function(){
     $(this).parent().parent().toggleClass("box-active")   
    })

    // console.log(localStorage.getItem('likeditems'))
    // let like=document.querySelectorAll('.product .action i')
    // let likeditems=[];
    // for(let i=0;i<like.length;i++){
    //     like[i].addEventListener("click",function(e){
    //         if(typeof(Storage) !=='undefined'){
    //              let likeditem={
    //                 id:i+1,
    //                 productimg:e.target.parentElement.parentElement.querySelector(".primary_image").src,
    //                 productname:e.target.parentElement.parentElement.children[1].textContent,
    //                 description:e.target.parentElement.parentElement.children[2].textContent,
    //                 productprice:e.target.parentElement.parentElement.querySelector(".product-price").getAttribute('data-price'),
    //              }
    //              if(localStorage.getItem('likeditems')){
    //                 let likedcartItems = JSON.parse(localStorage.getItem('likeditems'));
    //                 let likedcartIndex = likedcartItems.findIndex(x => x.id === likeditem.id);
    //                 if(likedcartIndex !== -1){
    //                     likeditems.splice(likedcartIndex, 1)
    //                     likedcartItems.splice(likedcartIndex, 1)
    //                     localStorage.setItem("likeditems",JSON.stringify(likedcartItems));
    //                 }
    //                 else{
    //                     likeditems.push(likeditem);
    //                     localStorage.setItem("likeditems",JSON.stringify(likeditems));
    //                 }
    //              }
    //              else{
    //                 likeditems.push(likeditem);
    //                 localStorage.setItem("likeditems",JSON.stringify(likeditems)) 
    //              }
    //         }
    //     }
    //     )
    // }

    // let dataitems=document.querySelectorAll(".products .container .item-inner .product");
    // var likedidcartItems =localStorage.getItem('likeditems');
    //     let parselikecartitems=JSON.parse(likedidcartItems);
    //     if(parselikecartitems){
    //         dataitems.forEach(product => {
    //             let dataId=product.getAttribute("data-id")
    //                 let element=parselikecartitems.findIndex(x=>x.id==dataId)
    //                 console.log(parselikecartitems)
    //                 if(element !== -1){
    //                     $(product).addClass('box-active')
    //                 }               
    //     })
    
    // }


    // let wishcontainer=document.querySelector(".wishlist tbody")
    // if(localStorage.getItem('likeditems')){
    //     JSON.parse(localStorage.getItem('likeditems')).map((likeddata,index)=>{
    //         console.log("slamalar"+index)
    //         if($(".wishlist tbody").length){
    //             wishcontainer.innerHTML+=`
    //             <tr class="item_cart" data-index="${index}"  data-id="${likeddata.id}">
    //                         <td class="product-photo"><img src="${likeddata.productimg}" alt="Futurelife" height="100" width="100"></td>
    //                         <td class="produc-name"><a href="#" title="">${likeddata.productname}</a></td>
    //                         <td class="description">${likeddata.description}</td>
    //                         <td class="product-price">${likeddata.productprice}</td>
    //                         <td class="product-avai">in stock</td>
    //                         <td class="add-to-cart"><a href="#" title=""><i class="fa fa-shopping-basket"></i></a></td>
    //                         <td class="product-remove"><a href="#" title="">x</a></td>
    
    //                     </tr>
    //             `
    //                     }
    //                     }
    //                     )
    // }
   
  
                   
    
    // let carts=document.querySelectorAll(".add-to-cart")
    // let items=[];
    // for(let i=0;i<carts.length;i++){
    //     carts[i].addEventListener("click",function(e){
    //         cartNumbers();
    //         if(typeof(Storage) !=='undefined'){
    //             let item={
    //                 id:i+1,
    //                 productimg:e.target.parentElement.querySelector(".primary_image").src,
    //                 productname:e.target.parentElement.children[1].textContent,
    //                 description:e.target.parentElement.children[2].textContent,
    //                 productprice:e.target.parentElement.querySelector(".product-price").getAttribute('data-price'),
    //                 quantity:1
    //             };

                
    //             if(localStorage.getItem('items')){
    //                 let cartItems = JSON.parse(localStorage.getItem('items'));
    //                 let cartIndex = cartItems.findIndex(x => x.id === item.id);
                    
    //                 if(cartIndex !== -1){
    //                     cartItems[cartIndex].quantity += 1;
    //                     localStorage.setItem("items",JSON.stringify(cartItems));
    //                 }
    //                 else {
    //                     cartItems.push(item);
    //                     localStorage.setItem("items",JSON.stringify(cartItems));
    //                 }
    //             }
    //             else {
    //                 items.push(item);
    //                 localStorage.setItem("items",JSON.stringify(items));
    //             }
    //         }
    //         else{
    //             alert('local storksjksj')
    //         }
    //     })
    // }
    
    // let productContainer=document.querySelector(".space-80 tbody")
    // let producttotallist=document.querySelector(".cart-list")
    // let productlist=document.querySelector(".cart-list .list")
    // if(JSON.parse(localStorage.getItem('cartNumbers'))==0){
    //     productContainer= ''
    //     productlist=''
    //     producttotallist.innerHTML=`
    //     <p class="total"><span>Total:</span>0</p>
    //                             <a class="checkout" href="#" title="">Check out</a>
    //     ` 
    // }
    // else{
    //     if(localStorage.getItem('items')){
    //         JSON.parse(localStorage.getItem('items')).map((data,index)=>{
    //             if($(".space-80 tbody").length){
    // productContainer.innerHTML +=`
    //                         <tr class="item_cart" data-index="${index}">
    //                                 <td class="product-photo"> <img src="${data.productimg}" class="img-fluid" alt="Futurelife" height="100" width="100"></td>
    //                                 <td class="produc-name">${data.productname}</td>
    //                                 <td class="description">${data.description}</td>
    //                                 <td class="product-price" data-price="${data.productprice}">${data.productprice}</td>
    //                                 <td class="product-quantity" data-quantity="${data.quantity}"><input class="nom" type="number" min="1" value="${data.quantity}" onkeydown="return false //return value false"></td>
    //                                 <td class="total-price">${data.productprice * data.quantity}</td>
    //                                 <td class="product-remove"><a href="#" title="">x</a></td>
    //                             </tr>
    //                         `
    //             }})
    //     }
    //     else{
    //         if($(".space-80 tbody").length){
    //             $(".space-80").html('<h3 style="text-align:center">Burada heç nə yoxdur</h3>')
    //         } 
    //     }
    //     }

    // // let carts1=document.querySelectorAll(".wishlist tbody tr .add-to-cart")
 
    
    
    // // let dataId=product.getAttribute("data-id")
    // // for(let i=0;i<carts1.length;i++){
    // //     carts1[i].addEventListener("click",function(e){
          
    // //         dataitems.forEach(product => {

    // //                let dataId=product.getAttribute("data-id");
                   
    // //             let carts1id = dataitems.findIndex(productone => productone.getAttribute("data-id") ===e.target.parentElement.parentElement.parentElement.getAttribute('data-id')); 

    // //             // console.log(product[carts1id])

    // //             // cartNumbers();
    // //             if(carts1id!==-1){
                    
    // //                     let item={
    // //                         id:i+1,
    // //                         productimg:product.querySelector(".primary_image").src,
    // //                         productname:product.children[1].textContent,
    // //                         description:product.children[2].textContent,
    // //                         productprice:product.querySelector(".product-price").getAttribute('data-price'),
    // //                         quantity:1
    // //                     };
    // //                     items.push(item);
                    
    // //             }
            
    // //     },
    // //         );
                
                 
    // //               console.log(items)
    // //             // console.log(dataitems[0])
    // //             // let element=parselikecartitems.findIndex(x=>x.id==dataId)
                
    // //         // console.log(e.target.parentElement.parentElement.parentElement.getAttribute('data-id'))
    // //         // console.log(item)

    // //     })
    // // }
        







    // function cartNumbers(){
    //     let productNumbers=localStorage.getItem('cartNumbers');
    //     productNumbers=parseInt(productNumbers);
    //     if(productNumbers){
    //         localStorage.setItem('cartNumbers',productNumbers+1);
    //         document.querySelector('.icon-cart span').textContent=productNumbers+1;
    //     }
    //     else{
    //         localStorage.setItem('cartNumbers',1);
    //         document.querySelector('.icon-cart span').textContent=1;
    //     }

             
    
    // }
    // function onLoadCartNumbers(){
    //     let productNumbers=localStorage.getItem('cartNumbers');
    //     if(productNumbers){
    //         document.querySelector('.icon-cart span').textContent=productNumbers;
    //         if(productNumbers<0){
    //             document.querySelector('.icon-cart span').textContent=0
    //             localStorage.setItem('cartNumbers',0)
    //         }
    //     }
    // }  

  
    // if($(".cart-totals").length){
    //     function totalprice(){
    //         var sumtotal = 0;
    //         $('tbody .total-price').each(function(){
    //             sumtotal += parseFloat(this.innerHTML);
    //         });
    //         return sumtotal;
    //     }
    //     var totalofsum=totalprice()
    //     console.log("saksjs"+totalofsum)
    
    //     localStorage.setItem("totalsprices",totalofsum)
    
    //     document.querySelector('.cart-totals ul li .number').innerText="$"+totalofsum;
    // }
    // onLoadCartNumbers();
    // $(".product-quantity input").bind('keyup mouseup', function () {
    //     let productNumbers=JSON.parse(localStorage.getItem('cartNumbers'));
    //     var sum = 0;
    //     $('.product-quantity input').each(function(){
    //         sum += parseFloat(this.value);
    //         return sum;
    //     });        
    //     function totalprice(){
    //         var sumtotal = 0;
    //         $('tbody .total-price').each(function(){
    //             sumtotal += parseFloat(this.innerHTML);
    //         });
    //         return sumtotal;
    
    //     }
    //     var totalsum=totalprice()
    //     localStorage.setItem("totalsprices",totalofsum)
    //     let count=document.querySelector('.icon-cart span').textContent;
    //     let quantity=$(this).val();
    //     let dataprice=$(this).parent().parent().find(".product-price").data("price");        
    //     let dataquantity=$(this).parent().parent().find(".product-quantity").data("quantity")
    //     let leavedquantity=dataquantity-quantity;
    //     leavedquantity=leavedquantity*-1;
    //     plusedquantity=parseInt(dataquantity)+parseInt(leavedquantity);
    //     dataquantity=plusedquantity;
    //     console.log(plusedquantity)
    //     let cartItems = JSON.parse(localStorage.getItem('items'));
    //     let itemquantity=$(this).parent().parent().data("index");       
    //     cartItems[itemquantity].quantity = parseInt(quantity);
    //     localStorage.setItem('items', JSON.stringify(cartItems));        
    //     let cartItemIndex = Number(this.parentElement.getAttribute('data-index'));
    //     cartItemIndex=cartItemIndex+plusedquantity;
    //     document.querySelector('.icon-cart span').textContent=sum;        
    //     let total=quantity*dataprice;
    //     $(this).parent().parent().find(".total-price").text(total);
    //     function totaloftotalprice(){
    //         var totaloftotal = 0;
    //         $('tbody .total-price').each(function(){
    //             totaloftotal+= parseFloat(this.innerHTML);
    //         });            
    //         return totaloftotal;    
    //     }
    //     var totaloftotal=totaloftotalprice()
    //     let leavedtotalprice=totalsum-totaloftotal
    //     leavedtotalprice=leavedtotalprice*-1
    //     finaltotalprice=totalsum+leavedtotalprice
    //     console.log(finaltotalprice)
    //     document.querySelector('.cart-totals ul li .number').innerText="$"+finaltotalprice;
    //     localStorage.setItem("totalsprices",finaltotalprice)
    //     localStorage.setItem('cartNumbers',sum);
    //     console.log(localStorage.getItem("totalsprices"))             
    // });

    
    // function deleteTr(e) {        
    //     var remove = document.querySelectorAll(".product-remove")
    //     remove.forEach(element => {
    //         element.addEventListener('click', () => {
    //             if($(".cart-totals").length){
    //                 let totalsum=element.parentElement.querySelector(".total-price").textContent
    //             console.log('salam'+totalsum)
    //             function totalprice(){
    //                 var sumtotal = 0;
    //                 $('tbody .total-price').each(function(){
    //                     sumtotal += parseFloat(this.innerHTML);
    //                 });
    //                 return sumtotal;            
    //             }
    //             var totalofsum=totalprice()
    //             Swal.fire({
    //                 title: 'Silmək istədiyinizdən əminsiniz?',
    //                 icon: 'warning',
    //                 showCancelButton: true,
    //                 confirmButtonColor: '#3085d6',
    //                 cancelButtonColor: '#d33',
    //                 confirmButtonText: 'Bəli!'
    //             }).then((result) => {
    //                 if (result.isConfirmed) {
    //                     let dataquantity=element.parentElement.parentElement.querySelector(".product-quantity").getAttribute('data-quantity');
    //                     // let quantity=element.parentElement.parentElement.querySelector(".product-quantity input").value;
    //                     dataquantity=parseInt(dataquantity);
    //                     console.log("salam"+totalofsum)
    //                     totalofsum=totalofsum-totalsum                        
    //                     document.querySelector('.cart-totals ul li .number').innerText="$"+totalofsum;
    //                     localStorage.setItem("totalsprices",totalofsum)
                        
    //                     let productNumbers=JSON.parse(localStorage.getItem('cartNumbers'));
    //                     element.parentElement.remove()
                        
    //                     function reloadindex(){
    //                         let cartItemIndex;
    //                         cartItemIndex=element.parentElement.getAttribute('data-index');
    //                         cartItemIndex=parseInt(cartItemIndex)
    //                         return cartItemIndex;
    //                     }
    //                     let cartItems = JSON.parse(localStorage.getItem('items'));
    //                     cartItems.splice(reloadindex(), 1)
    //                     var sum = 0;
    //                     $('.product-quantity input').each(function(){
    //                         sum += parseFloat(this.value);
    //                         return sum;
    //                     });
    //                     document.querySelector('.icon-cart span').textContent=sum;
                        
    //                     localStorage.setItem('cartNumbers',sum)
    //                     localStorage.setItem('items', JSON.stringify(cartItems));
    //                     Swal.fire(
    //                         'Deleted!',
    //                         'Your file has been deleted.',
    //                         'success'
    //                     )
    //                 }
    //             })
    //             }
                
    //         })
    //     });
    
    // }

    // function deleteTrWish(e) {
    //     var remove = document.querySelectorAll(".wishlist .product-remove")
    //     remove.forEach(element => {
    //         element.addEventListener('click', () => {

    //                     function reloadindex(){
    //                         let likedcartItemIndex;
    //                         likedcartItemIndex=element.parentElement.getAttribute('data-index');
    //                         likedcartItemIndex=parseInt(likedcartItemIndex)
    //                         return likedcartItemIndex;
    //                     }                       
    //                     let likedcartItems = JSON.parse(localStorage.getItem('likeditems'));                        
    //                     likedcartItems.splice(reloadindex(),1);
    //                     element.parentElement.remove()
    //                     localStorage.setItem('likeditems', JSON.stringify(likedcartItems));                        
    //     });
    
    // })}

    // deleteTr();
    // deleteTrWish();
       
